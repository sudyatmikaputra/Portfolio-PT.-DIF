database name = gotest
go mod name = gotest
more info in .env file