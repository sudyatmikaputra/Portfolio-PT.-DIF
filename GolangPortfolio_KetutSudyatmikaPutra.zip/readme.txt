1. GolangRESTAPIusingDDD = golang rest api using domain driven design structure
2. GolangSimpleRESTAPI = simple golang rest api
3. slackbotage = slack bot to calculate the age of user
4. tycoon0494 = simple tycoon game using golang
